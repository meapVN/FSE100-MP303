//initialize variables
let code = ""
let success = false;
let x = 0;
let y = 0;
let npcSize = [20, 20, 30, 30, 35, 50, 60, 60, 70, 75];
let npcX = [];
let npcY = [];
let bigX = 0;
let bigY = 0;
let bigXInc;
let bigYInc;
let npcXinc = [];
let npcYinc = [];
let npc_res_timer = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
let eaten_check = [
  false,
  false,
  false,
  false,
  false,
  false,
  false,
  false,
  false,
  false,
];
let res_timer_check = 100;
let bckgrnd;
let RESULT_TYPE = "";
let plyScore = 0;
let clock_icon;
let size_player = 40;
let tick = 0;
let timer = 60;
let GAME_HOME = true;
let GAME_RESULT = false;
let GAME_START = false;
let size_type_player = "small";
let size_type_npc = [
  "small",
  "small",
  "small",
  "small",
  "small",
  "medium",
  "medium",
  "medium",
  "medium",
  "medium",
];
let startText = "GAME START"

//preloading game assets
//Music from <a href="https://pixabay.com/music/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=music&amp;utm_content=6768">Pixabay</a>
function preload() {
  soundFormats("mp3", "wav");
  success_sfx = loadSound('asset/8-bit-powerup-6768.mp3')
  special_sprite = loadImage('asset/Special_Player_Fish.png')
  mrBig_sprite = loadImage("asset/mrBig.png");
  eat_sfx = loadSound("asset/eat_sfx.mp3");
  npc_sprite = loadImage("asset/small_fish_sprite.png");
  npc_sprite_small = loadImage("asset/small_fish_sprite.png");
  npc_sprite_medium = loadImage("asset/NPC_fish.png");
  npc_sprite_large = loadImage("asset/big_fish_sprite.png");
  player_sprite_small = loadImage("asset/Player_fish.png");
  player_sprite_medium = loadImage("asset/medium_player_sprite.png");
  player_sprite_large = loadImage("asset/large_player_sprite.png");
  lost_sfx = loadSound("asset/Game_over.wav");
  bckgrnd = loadImage("asset/Feeding_Frenzy_Background.jpg");
  clock_icon = loadImage("asset/clock_icon_1.png");
}

//setting up canvas and radom variables of NPC
function setup() {
  preload();
  createCanvas(windowWidth, windowHeight);
  npcX = [
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
  ];
  npcY = [
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
    random([100, 700]),
  ];
  npcXinc = [
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
  ];
  npcYinc = [
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
    random(0.5, 2),
  ];
  bigX = random([100, 700]);
  bigY = random([100, 700]);
  bigXInc = random(0.5, 1);
  bigYInc = random(0.5, 1);
  textSize(32);
  strokeWeight(2)
  stroke('white')
}

function draw() {
  background(bckgrnd);
  if (GAME_HOME) {
    //game start screen
    home_menu();
  }

  if (GAME_START) {
    //main game
    game_start();
  }

  if (GAME_RESULT) {
    //game over screen
    game_result();
  }
}

//attached mouse movement with player fish
function mouseMoved() {
  x = mouseX - size_player / 2;
  y = mouseY - size_player / 2;
}

//drawing main game
function game_start() {
  fill(0, 0, 0);
  textSize(32);
  text("Score", 50, 30);
  text(plyScore, 150, 30);
  time();
  player();
  for (i = 0; i <= 9; ++i) {
    npcFish(i);
    if (tick >= 600 && size_player >= 50) {
      NPCSizeIncrease(i);
    }
  }
  if (tick >= 2400) {
    MrBig();
  }
}

//drawing home screen
function home_menu() {
  fill("black");
  textSize(60);
  textAlign("center");
  text("FISH GAME", windowWidth / 2, 50);
  textSize(32);
  textAlign("center");
  text("HOW TO PLAY", windowWidth / 2, 100);
  textSize(32);
  textAlign("left");
  text("Use mouse to control your fish.", 200, 150);
  text("Eat smaller fish to grow bigger, and avoid bigger fish.", 200, 200);
  text("Be the biggest fish in the ocean, but be careful of Mr.Big.", 200, 250);
  textSize(60);
  fill("red");
  textAlign("center");

  //clicking at "GAME START" starts the game
  text(startText, windowWidth / 2, windowHeight / 2);
  if (success){
    startText = "GAME START*"
    size_player = 250;
    res_timer_check = 50;
    size_type_player = 'special'
  }
  //rect(windowWidth / 2 - 190, windowHeight / 2 - 50, 380, 50)
  if (
    mouseIsPressed === true &&
    mouseX >= windowWidth / 2 - 190 &&
    mouseX <= windowWidth / 2 + 190 &&
    mouseY >= windowHeight / 2 - 50 &&
    mouseY <= windowHeight / 2
  ) {
    GAME_HOME = false;
    GAME_RESULT = false;
    GAME_START = true;
  }
}

//drawing game over screen
function game_result() {
  clear();
  background(bckgrnd);
  fill("red");
  textSize(60);
  textAlign(CENTER);
  text("GAME OVER", windowWidth / 2, 200);
  textSize(32);
  text(RESULT_TYPE, windowWidth / 2, 250);
  text(concat("Score: ", plyScore), windowWidth / 2, 300);
  if (plyScore < 100){
    text('You will always be the biggest fish in my mind', windowWidth / 2, 350)
  }
  if (plyScore >= 100 && plyScore < 500){
    text('You can do better', windowWidth / 2, 350)
  }
  if (plyScore >= 500 && plyScore < 1000){
    text('Great job!!!', windowWidth / 2, 350)
  }
  if (plyScore >= 1000 && plyScore < 1250){
    text('Mr. Big Shot over here!!!', windowWidth / 2, 350)
  }
  if (plyScore >= 1250){
    text('You ARE the biggest fish now', windowWidth / 2, 350)
  }
  

  //clicking restarts the game and restart the variables
  text("Click to restart", windowWidth / 2, windowHeight / 2 + 100);
  if (mouseIsPressed) {
    plyScore = 0;
    size_player = 40;
    npcX = [
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
    ];
    npcY = [
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
      random([100, 700]),
    ];
    tick = 0;
    timer = 60;
    res_timer_check = 100;
    eaten_check = [
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
    ];
    size_type_player = "small";
    GAME_START = true;
    GAME_RESULT = false;
    GAME_HOME = false;
    npcSize = [20, 20, 30, 30, 35, 50, 60, 60, 70, 75];
    size_type_npc = [
      "small",
      "small",
      "small",
      "small",
      "small",
      "medium",
      "medium",
      "medium",
      "medium",
      "medium",
    ];
  }
}

//drawing player character
function player() {
  if (size_type_player === "small") {
    image(player_sprite_small, x, y, size_player, size_player);
  }
  //player change sprite when increase in size
  if (size_player >= 50 && size_player < 80) {
    size_type_player = "medium";
    image(player_sprite_medium, x, y, size_player, size_player);
  }

  //player change sprite when increase in size
  if (size_player >= 80 && size_player<=160) {
    image(player_sprite_large, x, y, size_player, size_player);
    size_type_player = "large";
  }
  if (size_type_player === "special") {
    image(special_sprite, x, y, size_player, size_player);
  }
}

//manage game timer
function time() {
  image(clock_icon, windowWidth - 220, 0, 80, 80);
  fill(0, 0, 0);
  textSize(32);
  text(timer, windowWidth - 245, 55);
  ++tick; //counting framerate to translate

  //count down the seconds
  if (tick % 60 == 0) {
    --timer;
  }

  //at 10 seconds left, fish will spawn faster
  if (tick >= 3000) res_timer_check = 50;

  //times up
  if (tick >= 3600) {
    lost_sfx.play();
    RESULT_TYPE = "TIME'S UP";
    GAME_START = false;
    GAME_HOME = false;
    GAME_RESULT = true;
  }
}

//drawing NPC fish
function npcFish(i) {
  if (eaten_check[i] === false) {
    //checking if fish[i] is eaten yet or not

    //checking for collision detection
    collision_detect(
      x,
      y,
      npcX[i],
      npcY[i],
      size_player,
      npcSize[i],
      size_type_npc[i]
    );

    //NPC fish movement
    if (npcX[i] > windowWidth - 200) {
      npcXinc[i] = random(-2, -0.5);
    }

    if (npcX[i] < 100) {
      npcXinc[i] = random(2, 0.5);
    }
    npcX[i] += npcXinc[i];

    if (npcY[i] > windowHeight - 200) {
      npcYinc[i] = random(-2, -0.5);
    }
    if (npcY[i] < 100) {
      npcYinc[i] = random(2, 0.5);
    }
    npcY[i] += npcYinc[i];

    //loading fish sprite
    if (size_type_npc[i] === "small") {
      image(npc_sprite_small, npcX[i], npcY[i], npcSize[i], npcSize[i]);
    }
    if (size_type_npc[i] === "medium") {
      image(npc_sprite_medium, npcX[i], npcY[i], npcSize[i], npcSize[i]);
    }
    if (size_type_npc[i] === "large") {
      image(npc_sprite_large, npcX[i], npcY[i], npcSize[i], npcSize[i]);
    }
  }

  //while fish is eaten
  if (eaten_check[i] === true) {
    if (npc_res_timer[i] <= res_timer_check) {
      //counting respawn timer
      ++npc_res_timer[i];
    } else {
      // when respaw timer is finished
      npcX[i] = random([100, windowWidth - 100]);
      npcY[i] = random([100, windowHeight - 100]);
      eaten_check[i] = false;
      npc_res_timer[i] = 0;
    }
  }
}

//collision detection
function collision_detect(
  x_player,
  y_player,
  x_npc,
  y_npc,
  size_p,
  size_npc,
  size_type
) {
  if (
    x_player + size_p > x_npc &&
    x_player < x_npc + size_npc &&
    y_player + size_p > y_npc &&
    y_player < y_npc + size_npc
  ) {
    //collided
    if (size_p >= size_npc) {
      //fish successfully eaten
      if (size_npc <=150) {
        eat_sfx.play();
      }
      if (size_player <= 120) {
        if (size_type === "small") {
          size_player += 1;
        }
        if (size_type === "medium") {
          size_player += 3;
        }
        if (size_type === "large") {
          size_player += 10;
        }
      }

      if (size_type === "small") {
        plyScore += 5;
      }
      if (size_type === "medium") {
        plyScore += 10;
      }
      if (size_type === "large") {
        plyScore += 15;
      }
      eaten_check[i] = true;
    } else {
      //player fish collide got eaten by bigger fish
      lost_sfx.play();
      RESULT_TYPE = "YOU WERE EATEN";
      GAME_START = false;
      GAME_HOME = false;
      GAME_RESULT = true;
    }
  }
}

function NPCSizeIncrease(i) {
  if (i === 3 || i === 4 || i === 5 || i === 6) {
    if (eaten_check[i]) {
      switch (i) {
        case 3:
          size_type_npc[i] = "large";
          npcSize[i] = 80;
          break;
        case 4:
          size_type_npc[i] = "large";
          npcSize[i] = 90;
          break;
        case 5:
          size_type_npc[i] = "large";
          npcSize[i] = 120;
          break;
        case 6:
          size_type_npc[i] = "large";
          npcSize[i] = 120;
          break;
      }
    }
  }
}

function MrBig() {
  if (bigX > windowWidth - 200) {
    bigXInc = random(-1, -0.5);
  }

  if (bigX < 100) {
    bigXInc = random(1, 0.5);
  }
  bigX += bigXInc;

  if (bigY > windowHeight - 200) {
    bigYInc = random(-1, -0.5);
  }
  if (bigY < 100) {
    bigYInc = random(1, 0.5);
  }
  bigY += bigYInc;
  image(mrBig_sprite, bigX, bigY, 250, 250);
  collision_detect(x, y, bigX, bigY, size_player, 250, 250);
}

function keyPressed() {
  if (keyCode === 27){
    window.open('https://editor.p5js.org/knnguy11/full/q9dvJKhNh')
  }
  if (GAME_HOME ) { //easter egg
    if (keyCode === UP_ARROW) {
      code += "1";
    }
    if (keyCode === DOWN_ARROW) {
      code += "2";
    }
    if (keyCode === LEFT_ARROW) {
      code += "3";
    }
    if (keyCode === RIGHT_ARROW) {
      code += "4";
    }
    if (keyCode === 65) {
      code += "5";
    }
    if (keyCode === 66) {
      code += "6";
    }
    if (keyCode === ENTER) {
      if (code === "1122343465") {
        success = true;
        success_sfx.play()
      } else {
        success = false;
        
        code = "";
      }
    }
  }
}
